﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openAddFaculty();
        }

        private void openAddFaculty()
        {
            try
            {
                AddFacultyForm fa = new AddFacultyForm();
                fa.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openAddTA();
        }

        private void openAddTA()
        {
            try
            {
                AddTAForm ta = new AddTAForm();
                ta.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openAddLD();
        }

        private void openAddLD()
        {
            try
            {
                AddLDForm ld = new AddLDForm();
                ld.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openDeleteTA();
        }

        private void openDeleteTA()
        {
            try
            {
                DeleteTAForm ta = new DeleteTAForm();
                ta.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            openDeleteLD();
        }

        private void openDeleteLD()
        {
            try
            {
                DeleteLDForm ld = new DeleteLDForm();
                ld.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            openDeleteFaculty();
        }

        private void openDeleteFaculty()
        {

            try
            {
                DeleteFacultyForm fd = new DeleteFacultyForm();
                fd.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
