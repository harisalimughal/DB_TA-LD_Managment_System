﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class MarksDetailsForm : Form
    {
        public MarksDetailsForm(int selectedFacultyID)
        {
            this.selectedFacultyID = selectedFacultyID;
            InitializeComponent();
            
        }

      

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private int selectedFacultyID;

        private void AddTAForm_Load(object sender, EventArgs e)
        {
            GetMarksDetails();
        }

        private void GetMarksDetails()
        {
            try
            {
                con.Open();

                // Assuming 'StuID' is the column representing Student ID in StudentCourseMarks
                // Replace 'EmployeeID' with the actual column name in the Faculty table that represents the faculty ID
                string query = @"
            SELECT
                Students.StuID,
                Students.StuName,
                Courses.CourseID,
                Courses.CourseName,
                StudentCourseMarks.MarksObtained,
                StudentCourseMarks.TotalMarks
            FROM
                Students
            JOIN
                StudentCourseMarks ON Students.StuID = StudentCourseMarks.StuID
            JOIN
                Courses ON StudentCourseMarks.CourseID = Courses.CourseID
            JOIN
                FacultyAssignments ON Courses.CourseID = FacultyAssignments.CourseID
            WHERE
                FacultyAssignments.EmployeeID = @FacultyID";

                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@FacultyID", selectedFacultyID); // Use the passed ID

                DataTable dt = new DataTable();
                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);

                con.Close();

                // Set the DataTable as the DataSource of the DataGridView
                FacultyRecordGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately (e.g., log the exception, show an error message)
                Console.WriteLine(ex.Message);
            }
        }




        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void FeedBack_Click(object sender, EventArgs e)
        {
            openTAFeedBack();
        }

        private void openTAFeedBack()
        {

            try
            {
                TAFeedBackForm fdm = new TAFeedBackForm();
                fdm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openLDFeedBack();
        }

        private void openLDFeedBack()
        {
            try
            {
                LDFeedBackForm fdm = new LDFeedBackForm();
                fdm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
