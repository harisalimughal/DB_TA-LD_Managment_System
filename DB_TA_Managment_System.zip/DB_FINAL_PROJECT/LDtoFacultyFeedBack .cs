﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class LDFeedBackForm : Form
    {
        public LDFeedBackForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private void AddTAForm_Load(object sender, EventArgs e)
        {
            LDToFacultyFeedBackRecord();
        }

        private void LDToFacultyFeedBackRecord()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from LDtoFacultyFeedback", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            LDtoFacFeedGridView.DataSource = dt;

        }


       
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void FeedBack_Click(object sender, EventArgs e)
        {
            openFacultytoLDFeedback();
        }

        private void openFacultytoLDFeedback()
        {
            try
             {
                 FacultytoLDFeedBackForm fdm = new FacultytoLDFeedBackForm();
                 fdm.Show();
             }
             catch (Exception ex)
             {
                 MessageBox.Show("Error: " + ex.Message);
             }
        }

        //  private void FeedBack_Click(object sender, EventArgs e)
        //  {
        //      openFacutlytoLD();
        //  }

            // private void openFacutlytoLD()
            // {
            //     try
            //     {
            //         FacultytoLDFeedBackForm fdm = new FacultytoLDFeedBackForm();
            //         fdm.Show();
            //     }
            //     catch (Exception ex)
            //     {
            //         MessageBox.Show("Error: " + ex.Message);
            //     }
            // }
    }  //
}      //
       //