﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;
            string role = cmbRole.SelectedItem.ToString();

            if (String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password) || String.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            string connectionString = "Data Source=Fatimas-PC\\SQLEXPRESS;Initial Catalog=DBFP;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Check if the user exists in TA, LD, or Faculty tables
                string userCheckQuery = @"
            SELECT CASE 
                WHEN EXISTS(SELECT 1 FROM TAs WHERE TAName = @username) THEN 'TA'
                WHEN EXISTS(SELECT 1 FROM LDs WHERE LDName = @username) THEN 'LD'
                WHEN EXISTS(SELECT 1 FROM Faculty WHERE Name = @username) THEN 'Faculty'
                ELSE NULL
            END";

                string userType = null;
                using (SqlCommand userCheckCmd = new SqlCommand(userCheckQuery, conn))
                {
                    userCheckCmd.Parameters.AddWithValue("@username", username);
                    var result = userCheckCmd.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        userType = (string)result;
                    }
                }

                if (userType == null)
                {
                    MessageBox.Show("Oops! Seems like you haven't been appointed yet. Check later Please!");
                    return;
                }


                if (userType != role)
                {
                    MessageBox.Show($"The selected role does not match the user's type. Expected: {userType}");
                    return;
                }

                // Insert into UserAuth table
                string query = "INSERT INTO UserAuth (Username, Password, Role, ReferenceID) VALUES (@username, @password, @role, IDENT_CURRENT('UserAuth') + 1)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password); // In a real app, this should be hashed
                    cmd.Parameters.AddWithValue("@role", role);

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Signup Successful");
                        SignupGreeting hello = new SignupGreeting();
                        hello.Show();
                    }
                    else
                    {
                        MessageBox.Show("Signup Failed");
                    }
                }
            }
        }




        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

