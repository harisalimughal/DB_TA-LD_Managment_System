﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DB_FINAL_PROJECT
{
    public partial class FacultytoTAFeedBackForm : Form
    {
        public FacultytoTAFeedBackForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private void AddTAForm_Load(object sender, EventArgs e)
        {
            GetfacultytoTAFeedBack();
        }

        private void GetfacultytoTAFeedBack()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from FacultyToTAFeedback", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            FacultytoTAFeedBackGridView.DataSource = dt;

        }


        private void TaskRecorddataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            txtFeedbackID.Text = FacultytoTAFeedBackGridView.SelectedRows[0].Cells[1].Value.ToString();
            txtTAID.Text = FacultytoTAFeedBackGridView.SelectedRows[0].Cells[2].Value.ToString();
            txtFacultyID.Text = FacultytoTAFeedBackGridView.SelectedRows[0].Cells[3].Value.ToString();
            txtFeedback.Text = FacultytoTAFeedBackGridView.SelectedRows[0].Cells[4].Value.ToString();


        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

 
       

        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddFeedback_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO FacultyToTAFeedback VALUES (@FeedbackID,@TAID, @FacultyID, @FeedbackText) ", con);
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@FeedbackID", txtFeedbackID.Text);
                cmd.Parameters.AddWithValue("@TAID", txtTAID.Text);
                cmd.Parameters.AddWithValue("@FacultyID", txtFacultyID.Text);
                cmd.Parameters.AddWithValue("@FeedbackText", txtFeedback.Text);
                
       
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
       
                MessageBox.Show("TA FeedBack Added Successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetfacultytoTAFeedBack();
            }
        }


        private bool IsValid()
        {
            if (txtFeedbackID.Text == string.Empty)
            {
                MessageBox.Show("Entry is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void FacultytoTAFeedBackGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
