﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class FacultyDetailsForm : Form
    {
        public FacultyDetailsForm(int selectedFacultyID)
        {
            this.selectedFacultyID = selectedFacultyID;
            InitializeComponent();
            
        }

      

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private int selectedFacultyID;

        private void AddTAForm_Load(object sender, EventArgs e)
        {
            GetFacultyDetails();
        }

        private void GetFacultyDetails()
        {
            try
            {
                con.Open();

                // Replace 'EmployeeID' with the actual column name in the Faculty table that represents the faculty ID
                string query = @"
            SELECT
                Faculty.EmployeeID,
                Faculty.Name AS FacultyName,
                Courses.CourseID,
                Courses.CourseName,
                Labs.LabID,
                Labs.LabName,
                TAs.TAID,
                TAs.TAName,
                LDs.LDID,
                LDs.LDName
            FROM
                Faculty
            LEFT JOIN
                FacultyAssignments ON Faculty.EmployeeID = FacultyAssignments.EmployeeID
            LEFT JOIN
                Courses ON FacultyAssignments.CourseID = Courses.CourseID
            LEFT JOIN
                Labs ON FacultyAssignments.LabID = Labs.LabID
            LEFT JOIN
                TAs ON TAs.CourseID = Courses.CourseID
            LEFT JOIN
                LDs ON LDs.LabID = Labs.LabID
            WHERE
                Faculty.EmployeeID = @FacultyID";

                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@FacultyID", selectedFacultyID); // Use the passed ID

                DataTable dt = new DataTable();
                System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);

                con.Close();

                FacultyRecordGridView.DataSource = dt;
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately (e.g., log the exception, show an error message)
                Console.WriteLine(ex.Message);
            }
        }



       
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        

      

       

        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void LDFeedBack_Click(object sender, EventArgs e)
        {

            if (selectedFacultyID != -1)
            {
                openMarksDetails();
            }
            else
            {
                MessageBox.Show("Please select a faculty before clicking the button.");
            }
        }

        private void openMarksDetails()
        {

            try
            {
                MarksDetailsForm fdm = new MarksDetailsForm(selectedFacultyID);
                fdm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
