﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class FacultyLogin : Form
    {
        private string userRole;
        public FacultyLogin(string role)
        {
            InitializeComponent();
            userRole = role;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

      
        private void button2_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text; 

            if (String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password are required.");
                return;

            }

            string connectionString = "Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True"; // Define your connection string
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(1) FROM UserAuth WHERE Username=@username AND Password=@password AND Role=@role";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password); // Use a hashed password here
                    cmd.Parameters.AddWithValue("@role", userRole);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    Console.WriteLine(count);
                    if (count == 1)
                    {
                        // Login success
                        MessageBox.Show("Login Successful");
                        FacultyDashboard fd = new FacultyDashboard();
                        fd.Show();
                    }
                    else
                    {
                        // Login failed
                        MessageBox.Show("Login Failed");

                    }
                }
            }
        }

        private void openFacultyDashboard()
        {
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Signup signupForm = new Signup();
            signupForm.Show();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void FacultyLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
