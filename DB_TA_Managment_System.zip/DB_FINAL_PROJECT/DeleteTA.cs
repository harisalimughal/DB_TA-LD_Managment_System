﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class DeleteTAForm : Form
    {
        public DeleteTAForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taid;
        private void DeleteLDForm_Load(object sender, EventArgs e)
        {
            GetLDRecord();
        }

        private void GetLDRecord()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from TAs", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            LDRecordGridView.DataSource = dt;

        }


       
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TARecordGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (taid > 0)
            {
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("DELETE FROM TAs WHERE TAID=@ID", con);
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.Parameters.AddWithValue("@ID", this.taid);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("TA Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetLDRecord();
                CompleteTasks();
            }
            else
            {
                MessageBox.Show("Please select a TA to delete", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsValid()
        {
            if (txtName.Text == string.Empty)
            {
                MessageBox.Show("Name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void CompleteTasks()
        {
            taid = 0;
            txtName.Clear();
            txtCgpa.Clear();
            txtCourseId.Clear();
            txtGrade.Clear();
            txtPay.Clear();

            txtName.Focus();
        }
        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void LDRecordGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
                taid = Convert.ToInt32(LDRecordGridView.SelectedRows[0].Cells[0].Value.ToString());
                txtName.Text = LDRecordGridView.SelectedRows[0].Cells[1].Value.ToString();
                txtCgpa.Text = LDRecordGridView.SelectedRows[0].Cells[2].Value.ToString();
                txtCourseId.Text = LDRecordGridView.SelectedRows[0].Cells[3].Value.ToString();
                txtGrade.Text = LDRecordGridView.SelectedRows[0].Cells[4].Value.ToString();
                txtPay.Text = LDRecordGridView.SelectedRows[0].Cells[5].Value.ToString();



        }
    }
}
