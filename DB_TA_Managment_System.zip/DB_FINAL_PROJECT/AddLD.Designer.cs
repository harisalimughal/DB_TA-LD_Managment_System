﻿namespace DB_FINAL_PROJECT
{
    partial class AddLDForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.LDRecordGridView = new System.Windows.Forms.DataGridView();
            this.lblName = new System.Windows.Forms.Label();
            this.CGPA = new System.Windows.Forms.Label();
            this.CourseId = new System.Windows.Forms.Label();
            this.CourseGrade = new System.Windows.Forms.Label();
            this.Pay = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtCgpa = new System.Windows.Forms.TextBox();
            this.txtCourseId = new System.Windows.Forms.TextBox();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.txtPay = new System.Windows.Forms.TextBox();
            this.txtLDID = new System.Windows.Forms.TextBox();
            this.LDID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.LDRecordGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(265, 227);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 47);
            this.button1.TabIndex = 3;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LDRecordGridView
            // 
            this.LDRecordGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(178)))), ((int)(((byte)(178)))));
            this.LDRecordGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LDRecordGridView.Location = new System.Drawing.Point(50, 280);
            this.LDRecordGridView.Name = "LDRecordGridView";
            this.LDRecordGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.LDRecordGridView.Size = new System.Drawing.Size(624, 178);
            this.LDRecordGridView.TabIndex = 5;
            this.LDRecordGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TARecordGridView_CellContentClick);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(46, 80);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(55, 20);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Name";
            this.lblName.Click += new System.EventHandler(this.label1_Click);
            // 
            // CGPA
            // 
            this.CGPA.AutoSize = true;
            this.CGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CGPA.Location = new System.Drawing.Point(46, 124);
            this.CGPA.Name = "CGPA";
            this.CGPA.Size = new System.Drawing.Size(58, 20);
            this.CGPA.TabIndex = 6;
            this.CGPA.Text = "CGPA";
            // 
            // CourseId
            // 
            this.CourseId.AutoSize = true;
            this.CourseId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseId.Location = new System.Drawing.Point(446, 124);
            this.CourseId.Name = "CourseId";
            this.CourseId.Size = new System.Drawing.Size(87, 20);
            this.CourseId.TabIndex = 7;
            this.CourseId.Text = "Course Id";
            // 
            // CourseGrade
            // 
            this.CourseGrade.AutoSize = true;
            this.CourseGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseGrade.Location = new System.Drawing.Point(46, 170);
            this.CourseGrade.Name = "CourseGrade";
            this.CourseGrade.Size = new System.Drawing.Size(121, 20);
            this.CourseGrade.TabIndex = 8;
            this.CourseGrade.Text = "Course Grade";
            // 
            // Pay
            // 
            this.Pay.AutoSize = true;
            this.Pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pay.Location = new System.Drawing.Point(446, 174);
            this.Pay.Name = "Pay";
            this.Pay.Size = new System.Drawing.Size(38, 20);
            this.Pay.TabIndex = 9;
            this.Pay.Text = "Pay";
            this.Pay.Click += new System.EventHandler(this.Pay_Click);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Location = new System.Drawing.Point(173, 70);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(244, 30);
            this.txtName.TabIndex = 10;
            // 
            // txtCgpa
            // 
            this.txtCgpa.Location = new System.Drawing.Point(173, 122);
            this.txtCgpa.Multiline = true;
            this.txtCgpa.Name = "txtCgpa";
            this.txtCgpa.Size = new System.Drawing.Size(78, 22);
            this.txtCgpa.TabIndex = 11;
            // 
            // txtCourseId
            // 
            this.txtCourseId.Location = new System.Drawing.Point(559, 126);
            this.txtCourseId.Multiline = true;
            this.txtCourseId.Name = "txtCourseId";
            this.txtCourseId.Size = new System.Drawing.Size(78, 22);
            this.txtCourseId.TabIndex = 12;
            // 
            // txtGrade
            // 
            this.txtGrade.Location = new System.Drawing.Point(173, 172);
            this.txtGrade.Multiline = true;
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(78, 22);
            this.txtGrade.TabIndex = 13;
            // 
            // txtPay
            // 
            this.txtPay.Location = new System.Drawing.Point(552, 172);
            this.txtPay.Multiline = true;
            this.txtPay.Name = "txtPay";
            this.txtPay.Size = new System.Drawing.Size(85, 22);
            this.txtPay.TabIndex = 14;
            // 
            // txtLDID
            // 
            this.txtLDID.Location = new System.Drawing.Point(559, 78);
            this.txtLDID.Multiline = true;
            this.txtLDID.Name = "txtLDID";
            this.txtLDID.Size = new System.Drawing.Size(78, 22);
            this.txtLDID.TabIndex = 15;
            // 
            // LDID
            // 
            this.LDID.AutoSize = true;
            this.LDID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDID.Location = new System.Drawing.Point(446, 76);
            this.LDID.Name = "LDID";
            this.LDID.Size = new System.Drawing.Size(56, 20);
            this.LDID.TabIndex = 16;
            this.LDID.Text = "LD ID";
            this.LDID.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // AddLDForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.ClientSize = new System.Drawing.Size(753, 470);
            this.Controls.Add(this.LDID);
            this.Controls.Add(this.txtLDID);
            this.Controls.Add(this.txtPay);
            this.Controls.Add(this.txtGrade);
            this.Controls.Add(this.txtCourseId);
            this.Controls.Add(this.txtCgpa);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.Pay);
            this.Controls.Add(this.CourseGrade);
            this.Controls.Add(this.CourseId);
            this.Controls.Add(this.CGPA);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.LDRecordGridView);
            this.Controls.Add(this.button1);
            this.Name = "AddLDForm";
            this.Text = "ADD LD";
            this.Load += new System.EventHandler(this.AddLDForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LDRecordGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView LDRecordGridView;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label CGPA;
        private System.Windows.Forms.Label CourseId;
        private System.Windows.Forms.Label CourseGrade;
        private System.Windows.Forms.Label Pay;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtCgpa;
        private System.Windows.Forms.TextBox txtCourseId;
        private System.Windows.Forms.TextBox txtGrade;
        private System.Windows.Forms.TextBox txtPay;
        private System.Windows.Forms.TextBox txtLDID;
        private System.Windows.Forms.Label LDID;
    }
}