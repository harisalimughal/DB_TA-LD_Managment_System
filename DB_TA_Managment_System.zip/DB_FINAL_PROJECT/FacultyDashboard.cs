﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class FacultyDashboard : Form
    {
        public FacultyDashboard()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openAddFaculty();
        }

        private void openAddFaculty()
        {
            try
            {
                AddFacultyForm fa = new AddFacultyForm();
                fa.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openAddTA();
        }

        private void openAddTA()
        {
            try
            {
                AddTAForm ta = new AddTAForm();
                ta.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openAddLD();
        }

        private void openAddLD()
        {
            try
            {
                AddLDForm ld = new AddLDForm();
                ld.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openDeleteTA();
        }

        private void openDeleteTA()
        {
            try
            {
                DeleteTAForm ta = new DeleteTAForm();
                ta.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            openDeleteLD();
        }

        private void openDeleteLD()
        {
            try
            {
                DeleteLDForm ld = new DeleteLDForm();
                ld.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private int selectedFacultyID = -1; // Assuming faculty IDs are integers
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                if (int.TryParse(dataGridView1.Rows[selectedRowIndex].Cells[0].Value.ToString(), out selectedFacultyID))
                {
                    // Successfully parsed the ID as an integer
                }
                else
                {
                    selectedFacultyID = -1; // Reset to an invalid value
                }
            }

        }


        private void button6_Click(object sender, EventArgs e)
        {
            if (selectedFacultyID != -1)
            {
                openFacultyDetails();
            }
            else
            {
                MessageBox.Show("Please select a faculty before clicking the button.");
            }
        }

        private void openFacultyDetails()
        {

            try
            {
                FacultyDetailsForm fdm = new FacultyDetailsForm(selectedFacultyID);
                fdm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void openDeleteFaculty()
        {

            try
            {
                DeleteFacultyForm fd = new DeleteFacultyForm();
                fd.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void FacultyDashboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dB_ProjectDataSet1.Faculty' table. You can move, or remove it, as needed.
            this.facultyTableAdapter.Fill(this.dB_ProjectDataSet1.Faculty);

        }

   
    }
}
