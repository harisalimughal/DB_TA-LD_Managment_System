﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class AddLDForm : Form
    {
        public AddLDForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private void AddLDForm_Load(object sender, EventArgs e)
        {
            GetLDRecord();
        }

        private void GetLDRecord()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from LDs", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            LDRecordGridView.DataSource = dt;

        }


        private void TaskRecorddataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taskid = Convert.ToInt32(LDRecordGridView.SelectedRows[0].Cells[0].Value.ToString());
            txtName.Text = LDRecordGridView.SelectedRows[0].Cells[1].Value.ToString();
            txtCgpa.Text = LDRecordGridView.SelectedRows[0].Cells[2].Value.ToString();
           txtCourseId.Text = LDRecordGridView.SelectedRows[0].Cells[4].Value.ToString();
            txtGrade.Text = LDRecordGridView.SelectedRows[0].Cells[5].Value.ToString();
            txtPay.Text = LDRecordGridView.SelectedRows[0].Cells[6].Value.ToString();


        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TARecordGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (IsValid())
            {
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO LDs VALUES (@LDID, @LDName, @CGPA, @CourseID, @CourseGrade, @Pay) ", con);
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@LDID", txtLDID.Text);
                cmd.Parameters.AddWithValue("@LDName", txtName.Text);
                cmd.Parameters.AddWithValue("@CGPA", txtCgpa.Text);
                cmd.Parameters.AddWithValue("@CourseID", txtCourseId.Text);
                cmd.Parameters.AddWithValue("@CourseGrade", txtGrade.Text);
                cmd.Parameters.AddWithValue("@Pay", txtPay.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("LD Added Successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetLDRecord();
            }
        }

        private bool IsValid()
        {
            if (txtName.Text == string.Empty)
            {
                MessageBox.Show("Name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

       
    }
}
