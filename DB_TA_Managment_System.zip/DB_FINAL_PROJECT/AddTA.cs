﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class AddTAForm : Form
    {
        public AddTAForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int taskid;
        private void AddTAForm_Load(object sender, EventArgs e)
        {
            GetTARecord();
        }

        private void GetTARecord()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from TAs", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            TARecordGridView.DataSource = dt;

        }


        private void TaskRecorddataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            taskid = Convert.ToInt32(TARecordGridView.SelectedRows[0].Cells[0].Value.ToString());
            txtName.Text = TARecordGridView.SelectedRows[0].Cells[1].Value.ToString();
            txtCgpa.Text = TARecordGridView.SelectedRows[0].Cells[2].Value.ToString();
           txtCourseId.Text = TARecordGridView.SelectedRows[0].Cells[3].Value.ToString();
            txtGrade.Text = TARecordGridView.SelectedRows[0].Cells[4].Value.ToString();
            txtPay.Text = TARecordGridView.SelectedRows[0].Cells[5].Value.ToString();


        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

 

        private void button1_Click(object sender, EventArgs e)
        {

            if (IsValid())
            {
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO TAs VALUES (@TAID,@TAName, @CGPA, @CourseID, @CourseGrade, @Pay) ", con);
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@TAID", txtTAID.Text);
                cmd.Parameters.AddWithValue("@TAName", txtName.Text);
                cmd.Parameters.AddWithValue("@CGPA", txtCgpa.Text);
                cmd.Parameters.AddWithValue("@CourseID", txtCourseId.Text);
                cmd.Parameters.AddWithValue("@CourseGrade", txtGrade.Text);
                cmd.Parameters.AddWithValue("@Pay", txtPay.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("TA Added Successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetTARecord();
            }
        }

        private bool IsValid()
        {
            if (txtName.Text == string.Empty)
            {
                MessageBox.Show("Name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        
    }
}
