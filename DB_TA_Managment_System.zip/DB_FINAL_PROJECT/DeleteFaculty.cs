﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_FINAL_PROJECT
{
    public partial class DeleteFacultyForm : Form
    {
        public DeleteFacultyForm()
        {
            InitializeComponent();
        }

      

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection("Data Source=HARIS-DESKTOP\\SQLEXPRESS;Initial Catalog=\"DB Project\";Integrated Security=True");
        public int fid;
        private void DeleteLDForm_Load(object sender, EventArgs e)
        {
            GetFacultyRecord();
        }

        private void GetFacultyRecord()
        {

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Select * from Faculty", con);
            DataTable dt = new DataTable();

            con.Open();

            System.Data.SqlClient.SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            FacultyRecordGridView.DataSource = dt;

        }


       
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FacultyRecordGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (fid > 0)
            {
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("DELETE FROM Faculty WHERE EmployeeID=@ID", con);
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.Parameters.AddWithValue("@ID", this.fid);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Faculty Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetFacultyRecord();
                CompleteTasks();
            }
            else
            {
                MessageBox.Show("Please select a task to delete", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsValid()
        {
            if (txtName.Text == string.Empty)
            {
                MessageBox.Show("Name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void CompleteTasks()
        {
            fid = 0;
            txtName.Clear();
           

            txtName.Focus();
        }
        private void Pay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void FacultyRecordGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
                fid = Convert.ToInt32(FacultyRecordGridView.SelectedRows[0].Cells[0].Value.ToString());
                txtName.Text = FacultyRecordGridView.SelectedRows[0].Cells[1].Value.ToString();
               



        }
    }
}
