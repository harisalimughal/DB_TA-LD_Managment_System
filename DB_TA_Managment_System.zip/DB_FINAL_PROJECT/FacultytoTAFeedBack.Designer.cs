﻿namespace DB_FINAL_PROJECT
{
    partial class FacultytoTAFeedBackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddFeedback = new System.Windows.Forms.Button();
            this.FacultytoTAFeedBackGridView = new System.Windows.Forms.DataGridView();
            this.CGPA = new System.Windows.Forms.Label();
            this.txtFacultyID = new System.Windows.Forms.TextBox();
            this.txtTAID = new System.Windows.Forms.TextBox();
            this.TAID = new System.Windows.Forms.Label();
            this.txtFeedback = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFeedbackID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.FacultytoTAFeedBackGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // AddFeedback
            // 
            this.AddFeedback.BackColor = System.Drawing.Color.Teal;
            this.AddFeedback.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddFeedback.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.AddFeedback.Location = new System.Drawing.Point(565, 184);
            this.AddFeedback.Name = "AddFeedback";
            this.AddFeedback.Size = new System.Drawing.Size(108, 32);
            this.AddFeedback.TabIndex = 3;
            this.AddFeedback.Text = "ADD";
            this.AddFeedback.UseVisualStyleBackColor = false;
            this.AddFeedback.Click += new System.EventHandler(this.AddFeedback_Click);
            // 
            // FacultytoTAFeedBackGridView
            // 
            this.FacultytoTAFeedBackGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FacultytoTAFeedBackGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.FacultytoTAFeedBackGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(178)))), ((int)(((byte)(178)))));
            this.FacultytoTAFeedBackGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FacultytoTAFeedBackGridView.Location = new System.Drawing.Point(50, 262);
            this.FacultytoTAFeedBackGridView.Name = "FacultytoTAFeedBackGridView";
            this.FacultytoTAFeedBackGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.FacultytoTAFeedBackGridView.Size = new System.Drawing.Size(623, 196);
            this.FacultytoTAFeedBackGridView.TabIndex = 5;
            this.FacultytoTAFeedBackGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FacultytoTAFeedBackGridView_CellContentClick);
            // 
            // CGPA
            // 
            this.CGPA.AutoSize = true;
            this.CGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CGPA.Location = new System.Drawing.Point(46, 124);
            this.CGPA.Name = "CGPA";
            this.CGPA.Size = new System.Drawing.Size(86, 20);
            this.CGPA.TabIndex = 6;
            this.CGPA.Text = "FacultyID";
            // 
            // txtFacultyID
            // 
            this.txtFacultyID.Location = new System.Drawing.Point(200, 122);
            this.txtFacultyID.Multiline = true;
            this.txtFacultyID.Name = "txtFacultyID";
            this.txtFacultyID.Size = new System.Drawing.Size(78, 22);
            this.txtFacultyID.TabIndex = 11;
            // 
            // txtTAID
            // 
            this.txtTAID.Location = new System.Drawing.Point(200, 94);
            this.txtTAID.Multiline = true;
            this.txtTAID.Name = "txtTAID";
            this.txtTAID.Size = new System.Drawing.Size(78, 22);
            this.txtTAID.TabIndex = 15;
            // 
            // TAID
            // 
            this.TAID.AutoSize = true;
            this.TAID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TAID.Location = new System.Drawing.Point(55, 92);
            this.TAID.Name = "TAID";
            this.TAID.Size = new System.Drawing.Size(55, 20);
            this.TAID.TabIndex = 16;
            this.TAID.Text = "TA ID";
            this.TAID.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtFeedback
            // 
            this.txtFeedback.BackColor = System.Drawing.Color.White;
            this.txtFeedback.Location = new System.Drawing.Point(200, 186);
            this.txtFeedback.Multiline = true;
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.Size = new System.Drawing.Size(319, 30);
            this.txtFeedback.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Your FeedBack";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(55, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "FeedBack ID";
            // 
            // txtFeedbackID
            // 
            this.txtFeedbackID.Location = new System.Drawing.Point(200, 64);
            this.txtFeedbackID.Multiline = true;
            this.txtFeedbackID.Name = "txtFeedbackID";
            this.txtFeedbackID.Size = new System.Drawing.Size(78, 22);
            this.txtFeedbackID.TabIndex = 20;
            this.txtFeedbackID.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // FacultytoTAFeedBackForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.ClientSize = new System.Drawing.Size(753, 470);
            this.Controls.Add(this.txtFeedbackID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFeedback);
            this.Controls.Add(this.TAID);
            this.Controls.Add(this.txtTAID);
            this.Controls.Add(this.txtFacultyID);
            this.Controls.Add(this.CGPA);
            this.Controls.Add(this.FacultytoTAFeedBackGridView);
            this.Controls.Add(this.AddFeedback);
            this.Name = "FacultytoTAFeedBackForm";
            this.Text = "Faculty To TAFeedBack";
            this.Load += new System.EventHandler(this.AddTAForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FacultytoTAFeedBackGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button AddFeedback;
        private System.Windows.Forms.DataGridView FacultytoTAFeedBackGridView;
        private System.Windows.Forms.Label CGPA;
        private System.Windows.Forms.TextBox txtFacultyID;
        private System.Windows.Forms.TextBox txtTAID;
        private System.Windows.Forms.Label TAID;
        private System.Windows.Forms.TextBox txtFeedback;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFeedbackID;
    }
}